#!/usr/bin/env python3
"""Build a transparent, static 2026 Seahawks defensive data snapshot.
Sources: nflverse public release CSVs. No invented values are used.
"""
import json, os, io
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd
import requests

BASE = "https://github.com/nflverse/nflverse-data/releases/download"
OUT = Path("public/data/seahawks-2026.json")
SEASON = int(os.getenv("NFL_SEASON", "2026"))

def get_csv(url, **kwargs):
    r = requests.get(url, timeout=120)
    r.raise_for_status()
    return pd.read_csv(io.BytesIO(r.content), **kwargs)

def num(row, key):
    v = row.get(key)
    return None if pd.isna(v) else float(v)

# Team aggregate and player aggregate are released as regular-season CSVs.
team_url = f"{BASE}/stats_team/stats_team_reg_{SEASON}.csv"
player_url = f"{BASE}/stats_player/stats_player_reg_{SEASON}.csv"
team_df = get_csv(team_url)
player_df = get_csv(player_url)

# Team-level dataset contains team offense and opponent/defense fields.
sea = team_df[team_df["team"].astype(str).str.upper().eq("SEA")]
if sea.empty:
    raise RuntimeError("Seattle team row not found in nflverse team stats release.")
team_row = sea.iloc[0].to_dict()

# PBP is the auditable source for opponent play context and weekly trends.
pbp_url = f"{BASE}/pbp/play_by_play_{SEASON}.csv"
pbp = get_csv(pbp_url, low_memory=False)
required = {"defteam", "posteam", "week", "epa", "yards_gained", "down", "ydstogo"}
missing = sorted(required - set(pbp.columns))
if missing:
    raise RuntimeError(f"PBP release missing expected columns: {missing}")
defense = pbp[pbp["defteam"].astype(str).str.upper().eq("SEA")].copy()
# Exclude rows without a valid play type/epa when computing play averages.
valid = defense[defense["epa"].notna()].copy()

weekly = []
for week, g in valid.groupby("week"):
    weekly.append({
        "week": int(week),
        "opp_epa": round(float(g["epa"].mean()), 4) if len(g) else None,
        "opp_yards": round(float(g["yards_gained"].mean()), 2) if g["yards_gained"].notna().any() else None,
        "opp_points": None
    })

# Robustly map player-stat columns; absent fields remain zero only for additive
# counting stats that are present in the official nflverse player release.
team_col = "team" if "team" in player_df.columns else ("recent_team" if "recent_team" in player_df.columns else None)
if team_col is None:
    raise RuntimeError("Player stats release has no team/recent_team column.")
sea_players = player_df[player_df[team_col].astype(str).str.upper().eq("SEA")].copy()
def first_col(candidates):
    return next((c for c in candidates if c in sea_players.columns), None)
name_col = first_col(["player_name", "name"])
position_col = first_col(["position", "pos"])
games_col = first_col(["games", "games_played", "gp"])
tackle_col = first_col(["def_tackles", "def_tackle", "tackles"])
solo_col = first_col(["def_tackles_solo", "solo_tackles"])
assist_col = first_col(["def_tackle_assists", "def_tackles_with_assist", "assist_tackles"])
sack_col = first_col(["def_sacks", "sacks"])
int_col = first_col(["def_interceptions", "def_ints", "interceptions"])
ff_col = first_col(["def_fumbles_forced", "forced_fumbles"])
pd_col = first_col(["def_pass_defended", "pass_defended", "passes_defended"])
players = []
if name_col:
    for _, row in sea_players.iterrows():
        players.append({
            "player_name": str(row[name_col]),
            "position": str(row[position_col]) if position_col and pd.notna(row[position_col]) else "—",
            "games": int(row[games_col]) if games_col and pd.notna(row[games_col]) else 0,
            "tackles": int((row[tackle_col] if tackle_col else 0) if solo_col is None and assist_col is None else ((row[solo_col] if solo_col and pd.notna(row[solo_col]) else 0) + (row[assist_col] if assist_col and pd.notna(row[assist_col]) else 0))),
            "sacks": round(float(row[sack_col]), 1) if sack_col and pd.notna(row[sack_col]) else 0,
            "interceptions": int(row[int_col]) if int_col and pd.notna(row[int_col]) else 0,
            "forced_fumbles": int(row[ff_col]) if ff_col and pd.notna(row[ff_col]) else 0,
            "pass_defended": int(row[pd_col]) if pd_col and pd.notna(row[pd_col]) else 0
        })

# Opponent third-down conversion rate, derived from opponent offensive snaps.
third = valid[(valid["down"] == 3)]
third_rate = None
if len(third) and "first_down" in third.columns:
    third_rate = float(third["first_down"].fillna(0).mean())

def pick(row, keys):
    for k in keys:
        if k in row and pd.notna(row[k]):
            return float(row[k])
    return None

plays = []
for _, row in valid.tail(1200).iterrows():
    plays.append({
        "week": int(row["week"]) if pd.notna(row["week"]) else 0,
        "game_id": str(row.get("game_id", "")),
        "desc": str(row.get("desc", "")) if pd.notna(row.get("desc")) else "",
        "down": int(row["down"]) if pd.notna(row["down"]) else None,
        "ydstogo": int(row["ydstogo"]) if pd.notna(row["ydstogo"]) else None,
        "yards_gained": int(row["yards_gained"]) if pd.notna(row["yards_gained"]) else None,
        "epa": round(float(row["epa"]), 3) if pd.notna(row["epa"]) else None,
        "play_type": str(row.get("play_type", "")),
        "success": int(row["success"]) if "success" in row and pd.notna(row["success"]) else None
    })

games = int(defense["game_id"].nunique()) if "game_id" in defense.columns else 0
# Explicitly prefer fields from team-level release when present.
# Derive points and yards allowed from PBP so the headline figures share
# the same season snapshot as the play-level analysis.
opponent_points = None
if {"game_id", "home_team", "away_team", "total_home_score", "total_away_score"}.issubset(defense.columns):
    finals = defense.sort_values("play_id" if "play_id" in defense.columns else "game_id").groupby("game_id", as_index=False).tail(1)
    scored = []
    for _, game in finals.iterrows():
        score = game["total_away_score"] if str(game["home_team"]).upper() == "SEA" else game["total_home_score"]
        if pd.notna(score): scored.append(float(score))
    if scored: opponent_points = sum(scored)
# Sum offensive yards from opponent plays, then divide by unique games in UI.
opponent_yards = float(valid["yards_gained"].fillna(0).sum()) if "yards_gained" in valid.columns else None
turnovers = pick(team_row, ["def_turnovers", "takeaways", "def_ints"])
payload = {
    "meta": {
        "season": SEASON,
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "status": "ready",
        "sources": [team_url, player_url, pbp_url],
        "notes": [
            "Generated from public nflverse CSV releases.",
            "Only regular-season data is requested by this pipeline.",
            "Player metric mappings depend on columns present in the published release; unavailable fields are not inferred.",
            "Field coordinates and player tracking are not included in play-by-play data."
        ]
    },
    "team": {
        "games": games,
        "opp_points_per_game": None if opponent_points is None or not games else round(opponent_points / games, 2),
        "opp_yards_per_game": None if opponent_yards is None or not games else round(opponent_yards / games, 2),
        "third_down_rate": third_rate,
        "defensive_epa_per_play": round(float(valid["epa"].mean()), 4) if len(valid) else None,
        "turnovers": turnovers
    },
    "players": players,
    "weekly": sorted(weekly, key=lambda x: x["week"]),
    "plays": plays,
    "league": []
}
OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(json.dumps(payload, indent=2), encoding="utf-8")
print(f"Wrote {OUT} — {games} SEA defensive games, {len(players)} player rows, {len(plays)} plays.")
